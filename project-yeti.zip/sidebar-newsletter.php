<div class="py-sidebar-newsletter">
	<div class="row">
		<?php dynamic_sidebar("Newsletter"); ?>
	</div>
</div>