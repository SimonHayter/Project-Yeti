<?php get_header(); ?>
<div id="post-0" class="row post no-results not-found entry-content">
	<div class="large-12 columns">
		<header>
			<h1><?php _e( 'Nothing Found', 'projectyeti' ); ?></h1>
		</header>
		<span><?php _e( 'Sorry, but we could not find what you was looking for...', 'projectyeti' ); ?></span>
	</div>
</div>
<?php get_footer(); ?>